package com.blog.model;

import java.sql.Date;

import org.antlr.v4.runtime.misc.NotNull;
import org.springframework.validation.annotation.Validated;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import lombok.Data;
import lombok.NonNull;

@Entity
public class Posts {
@Id
@GeneratedValue(strategy = GenerationType.IDENTITY)

private Long id;

private String title;
private String content ;
Date  createdAt;
}
