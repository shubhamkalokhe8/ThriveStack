package com.blog.serviceimpl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.blog.model.Posts;
import com.blog.repository.BlogRepository;
import com.blog.servicei.blogservicei;
@Service
public class BlogServiceImpl implements blogservicei{
@Autowired
BlogRepository br;
	@Override
	public void savePost(Posts p) {
	br.save(p);
		
	}
	@Override
	public List<Posts> viewAllPosts() {
		Iterable<Posts> findAll = br.findAll();
		return (List<Posts>) findAll;
	}

	
}
