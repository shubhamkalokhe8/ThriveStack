package com.blog.servicei;

import java.util.List;

import com.blog.model.Posts;

public interface blogservicei {
public void savePost(Posts p);
public List<Posts>viewAllPosts();
}
