package com.blog.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.blog.model.Posts;
import com.blog.servicei.blogservicei;

@RestController
public class BlogController {
	@Autowired
	blogservicei bsei;
@PostMapping("/createPost")
public void savePost(@RequestBody Posts p)
{
	bsei.savePost(p);
}
@GetMapping("/viewAllPosts")
public List<Posts>viewAllPosts()
{
	List<Posts> viewAllPosts = bsei.viewAllPosts();
	return viewAllPosts;
}
}
